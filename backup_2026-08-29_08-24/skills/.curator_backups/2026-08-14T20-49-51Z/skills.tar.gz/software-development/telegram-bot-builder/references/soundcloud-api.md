# SoundCloud API Integration (Direct, no yt-dlp)

## Problem
yt-dlp's SoundCloud extractor returns HTTP 404 from cloud/VPS servers. The official SoundCloud API requires OAuth. Solution: use SoundCloud's internal API v2 with a scraped `client_id`.

## Step 1: Get client_id from SoundCloud homepage

```python
import requests, re, json

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                   'AppleWebKit/537.36 (KHTML, like Gecko) '
                   'Chrome/120.0.0.0 Safari/537.36'
}

def get_client_id() -> str:
    resp = requests.get('https://soundcloud.com', headers=HEADERS, timeout=15)
    match = re.search(
        r'window\.__sc_hydration\s*=\s*(\[.*?\]);\s*</script>',
        resp.text, re.DOTALL
    )
    data = json.loads(match.group(1))
    for item in data:
        if item.get('hydratable') == 'apiClient':
            return item['data']['id']
    raise RuntimeError("client_id not found")
```

## Step 2: Resolve any SoundCloud URL

```python
def resolve_url(url: str) -> dict:
    client_id = get_client_id()
    resp = requests.get(
        'https://api-v2.soundcloud.com/resolve',
        params={'url': url, 'client_id': client_id},
        headers=HEADERS, timeout=20
    )
    resp.raise_for_status()
    return resp.json()
```

Returns `kind`: `playlist`, `track`, or `user`. Playlists include `tracks[]` array with `id`, `title`, `duration`.

For large playlists, check `next_href` for pagination:
```python
next_href = data.get('next_href')
while next_href:
    page = requests.get(next_href, headers=HEADERS, timeout=20).json()
    tracks.extend(page.get('collection', []))
    next_href = page.get('next_href')
```

## Step 3: Get direct MP3 download URL

```python
def get_download_url(track_id: int) -> str | None:
    client_id = get_client_id()
    track = requests.get(
        f'https://api-v2.soundcloud.com/tracks/{track_id}',
        params={'client_id': client_id},
        headers=HEADERS, timeout=20
    ).json()

    transcodings = track.get('media', {}).get('transcodings', [])
    # Prefer 'progressive' protocol (direct MP3), not 'hls'
    progressive = next(
        (t for t in transcodings if t.get('format', {}).get('protocol') == 'progressive'),
        transcodings[0] if transcodings else None
    )
    if not progressive:
        return None

    stream = requests.get(
        progressive['url'],
        params={'client_id': client_id},
        headers=HEADERS, timeout=20
    ).json()
    return stream.get('url')  # Direct MP3 URL, time-limited
```

## Key API Endpoints

| Endpoint | Purpose |
|---|---|
| `GET /resolve?url=<soundcloud_url>` | Resolve any SC URL to its data |
| `GET /tracks/<id>` | Get full track info including transcodings |
| `GET /users/<id>/playlists` | Get user's playlists (with pagination) |
| `GET /search/playlists?q=<query>` | Search playlists |
| `GET /media/<hash>/stream/progressive` | Get direct MP3 stream URL |

## Response Structure

**Playlist** (`kind: "playlist"`):
- `title`, `track_count`, `tracks[]` (each with `id`, `title`, `duration`, `user`)

**Track** (`kind: "track"`):
- `id`, `title`, `duration`, `streamable`, `downloadable`
- `media.transcodings[]`: each has `url`, `preset`, `format.protocol`
  - `progressive` = direct MP3 (✅ use this)
  - `hls` = HTTP Live Streaming (needs ffmpeg to convert)
  - `cbc-encrypted-hls` = encrypted HLS

**Download URL response**: `{ "url": "https://cf-media.sndcdn.com/..." }` — time-limited, generates a fresh signed URL.

## Pitfalls

- **client_id may rotate.** If resolve returns 404 unexpectedly, re-scrape the homepage for a fresh client_id.
- **Progressive transcoding may not exist** for some tracks. Fall back to HLS + ffmpeg if needed.
- **Download URLs are time-limited** (signed with Policy). Don't cache them long.
- **Some tracks are not streamable** (`streamable: false`). These won't have transcodings.
- **Search API returns `collection[]`**, not direct results. Parse accordingly.
- **⚠️ Playlist tracks missing titles (CRITICAL).** SoundCloud's playlist API only returns full details (title, duration, media) for the first ~5 tracks. Remaining tracks have an `id` but **no `title`** (and may be missing other fields). You MUST resolve each incomplete track individually via `GET /tracks/<id>` to get its title. Without this, tracks 6+ display as "بدون عنوان" (no title). See code pattern:

```python
# After getting playlist tracks, resolve those missing titles
unresolved = [t for t in tracks if t and not t.get('title') and t.get('id')]
for t in unresolved:
    full = requests.get(
        f'https://api-v2.soundcloud.com/tracks/{t["id"]}',
        params={'client_id': client_id}, headers=HEADERS, timeout=20
    ).json()
    t['title'] = full.get('title', f"Track #{t['id']}")
    t['duration'] = full.get('duration')
    t['media'] = full.get('media', {})
```
