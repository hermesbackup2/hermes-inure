---
name: telegram-bot-builder
description: "Build and run Telegram bots with python-telegram-bot."
version: 0.1.0
author: Hermes
metadata:
  hermes:
    tags: [Telegram, Bot, Python, API]
---

# Telegram Bot Builder

Build Telegram bots using Python and `python-telegram-bot`. Supports commands, inline keyboards, callback handlers, and multi-source API integration.

## When to Use

- User asks to build a Telegram bot
- User asks to create a bot for notifications, data fetching, or automation
- User asks to run a bot that shows live data (prices, news, etc.)

## Prerequisites

- Python 3.10+
- `pip install python-telegram-bot requests`
- A bot token from @BotFather
- For 24/7: Railway.app account (free $5/mo credit)

## How to Get a Bot Token

1. Open Telegram → go to **@BotFather**
2. Send `/newbot`
3. Choose a name (e.g., "My Bot")
4. Choose a username (must end in `bot`)
5. Copy the token (format: `123456:ABC-DEF...`)

## Quick Reference

| Task | Command/Code |
|---|---|
| Get token | @BotFather → `/newbot` |
| Run locally | `python3 bot.py` |
| Run background | `nohup python3 bot.py > bot.log 2>&1 &` |
| Deploy Railway | Push to GitHub → Railway → Deploy from repo |
| Set env var | Railway → Variables → `BOT_TOKEN` = value |
| Check logs | Railway → Logs tab |
| Revoke token | @BotFather → `/revoke` |

## Procedure

### 1. Create bot.py

Use this structure:
```python
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

BOT_TOKEN = "YOUR_TOKEN"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [[InlineKeyboardButton("Button", callback_data="action")]]
    await update.message.reply_text("Hello!", reply_markup=InlineKeyboardMarkup(keyboard))

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    # handle q.data

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(callback_handler))
    app.run_polling()

if __name__ == "__main__":
    main()
```

### 2. Run Directly

```bash
python3 bot.py
```

The bot starts polling immediately. Ctrl+C to stop.

### 3. Run in Background (server)

```bash
nohup python3 bot.py > bot.log 2>&1 &
# or use screen/tmux for detachable session
```

### 4. Test

Send `/start` to the bot in Telegram.

### 5. Deploy to Railway (24/7)

**Files needed:**
- `requirements.txt` — list Python deps
- `Procfile` — contains: `worker: python3 bot.py`

**Steps:**
1. Push code to GitHub (**ASK USER FIRST**)
2. Go to railway.app → Sign in with GitHub
3. New Project → Deploy from GitHub repo
4. In Variables tab, add: `BOT_TOKEN` = user's token
5. Railway auto-deploys

**Railway environment variables:**
```
BOT_TOKEN=your-token-here
```

**Python version:** Railway defaults to Python 3.13. If needed, add `python_version="3.11"` to `nixpacks.toml`.

## Key Patterns

- **Inline keyboards**: `InlineKeyboardButton` + `CallbackQueryHandler`
- **Multi-source APIs**: Try multiple endpoints, merge results, use first successful
- **SoundCloud integration**: Don't use yt-dlp — use SoundCloud API v2 directly. See `references/soundcloud-api.md` for client_id scraping + progressive stream download technique. See `templates/soundcloud_bot.py` for a complete working example with pagination.
- **Playlist pagination**: SoundCloud playlist API uses `next_href` for pagination — fetch all pages in a loop, then resolve missing track titles individually via `GET /tracks/<id>`. Template shows `send_playlist_page()` with ⬅️/➡️ navigation and `PAGE_SIZE` constant.
- **Price formatting**: `f"{int(float(price)):,}"` for comma-separated Iranian numbers
- **Error handling**: Wrap each API call in try/except, log warnings, continue to next source
- **User-Agent header**: Some APIs block bare requests — always set `headers={"User-Agent": "Mozilla/5.0"}`
- **Timeout config for cloud**: Always set 30s timeouts when deploying to Railway/cloud:
  ```python
  app = Application.builder().token(TOKEN).read_timeout(30).write_timeout(30).connect_timeout(30).build()
  app.run_polling(drop_pending_updates=True)
  ```
- **Token via env var**: Never hardcode tokens. Use `os.environ.get("BOT_TOKEN")`

## Pitfalls

1. **Don't push bot code to GitHub with the token in it.** The token is a secret. If the repo is public, the token gets scraped and the bot gets hijacked.

2. **yt-dlp SoundCloud extraction fails from cloud servers (404).** SoundCloud API blocks yt-dlp's SoundCloud extractor from non-residential IPs. Don't use yt-dlp for SoundCloud — use the SoundCloud API directly. See `references/soundcloud-api.md` for the working approach. Also: playlist API only returns titles for first ~5 tracks; the rest need individual resolution via `GET /tracks/<id>`.

3. **SoundCloud playlist pagination missing.** The `/resolve` endpoint only returns the first page of tracks (typically 20-50). The full playlist requires following `next_href` in a loop until exhausted. Then each track missing a title must be resolved individually via `GET /tracks/<id>`. The template `soundcloud_bot.py` implements this in `get_playlist_tracks()` and `send_playlist_page()`.

4. **Don't create GitHub repos without user asking.** Build and run locally first. Only push when explicitly asked.

3. **Iranian APIs may be blocked from non-Iranian servers.** If running outside Iran, some APIs (tala.ir, sarafario.ir) will fail. Add multiple fallback sources.

4. **Bot stops when terminal closes.** Use `nohup`, `screen`, or `systemd` for persistent operation. Or deploy to Railway/VPS.

5. **python-telegram-bot v20+ uses async.** All handlers must be `async def`. Use `await` for API calls.

6. **Railway timeout errors (`httpx.ReadTimeout`).** Default timeouts are too short for cloud. Always set `read_timeout=30`, `write_timeout=30`, `connect_timeout=30`. Add `drop_pending_updates=True` to `run_polling()`.

7. **User wants direct execution, not instructions.** When user asks to build a bot, build and run it directly. Don't just provide code and say "run this yourself." If BotFather token is provided, wire it up and start the bot.

8. **Official vs market exchange rates.** International APIs (exchangerate-api.com) give official government rates, not open market rates. For Iranian market: official ~1,340,000 IRR/USD vs market ~1,890,000 IRR/USD. If accuracy matters, use Iranian APIs (only work from Iran) or show international prices (gold, silver) instead.

9. **Railway deployment workflow.** Push to GitHub → Railway auto-deploys → set `BOT_TOKEN` in Variables tab → wait 1-2 min. If bot crashes, check Logs tab. Common: missing env var, timeout errors, API blocked.

10. **Bot token security.** Never commit token to git. Always use `os.environ.get("BOT_TOKEN")`. If token leaked, revoke via @BotFather → `/revoke`.

11. **Background bot processes don't affect agent resources.** A Python bot running in `terminal(background=true)` is a separate OS process. It consumes server RAM/CPU but does NOT consume agent tokens or slow down the agent conversation. Safe to leave running. User can kill/restart on demand with a simple command.

12. **On-demand bot restart via agent.** Users may want to start/stop bots on demand rather than running 24/7. Store the bot's startup command in memory so the agent can restart it when asked. Pattern:
    - User says something like "ربات X رو روشن کن" (start bot X)
    - Agent looks up the command in memory and runs `terminal(background=true)` with `notify_on_complete=true`
    - User says "خاموشش کن" (shut it down)
    - Agent finds the process session_id and calls `process(action='kill')`
    - Store in memory: `Bot X: when user says "ربات X رو راه بنداز" auto-start /path/to/bot.py with token TOKEN via background terminal.`
    - This is safer than Railway for bots that don't need 24/7 uptime.

## Verification

```bash
# Bot should print "started" and connect to Telegram
python3 bot.py 2>&1 | head -5
# Expected: "✅  ربات در حال اجراست..." or similar
```
